#@{Data="Hello World $(Get-Date) - Love Doug"} | ConvertTo-Json > $res

'other data' > $res